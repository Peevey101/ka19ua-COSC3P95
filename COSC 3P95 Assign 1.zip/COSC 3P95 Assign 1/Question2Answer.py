# COSC 3P95 Assignment 1
# Student Name: Oreoluwa Akanji
# Student Number: 6910483

# a bubble sort algorithm that sorts integers in ascending order
import random


def bubble_sort(intList):  # define the bubble sort function
    n = len(intList)  # the length of the list of integers
   # loop through each element in the list
    for i in range(n):
        for j in range(0, n - i - 1):
            # swap if the element found is greater than the next element
            if intList[j] > intList[j + 1]:
                intList[j], intList[j + 1] = intList[j + 1], intList[j]
    return intList  # return the sorted list


def rand_test_generator():
    num_tests = random.randint(10, 1000)  # define the number of test cases

    test_cases = []  # initialize an empty list to hold the test cases

    for _ in range(num_tests):  # generate each test case
        # randomly determine the length of the array (between 0 and 1000)
        array_length = random.randint(0, 1000)

        # generate an array of random integers (between -1000 and 1000)
        array = [random.randint(-1000, 1000) for _ in range(array_length)]

        test_cases.append(array)  # add the array to the list of test cases

    return test_cases


test_cases = rand_test_generator()  # generate a list of test cases
for i, test_case in enumerate(test_cases):
    # print the test case number and its value
    print(f"Test case {i+1}: {test_case}")
